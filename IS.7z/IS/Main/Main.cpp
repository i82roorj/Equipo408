#include "Main.h"

using namespace std;


void main (){

    cout<<"Bienvenido al programa, por favor seleccione una de las opciones validad "<<endl;
    Main M;
    //Display();
    
};
