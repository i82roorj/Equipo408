#include <iostream>
#include <fstream>
#ifndef MAIN_H
#define MAIN_H
using namespace std;


class Main {
private:

public:

void consultarManual();
void consultarInfoAdmin();
void confirmarAccion();
void Display();

void ConsultarManual(){

};


};
#endif
